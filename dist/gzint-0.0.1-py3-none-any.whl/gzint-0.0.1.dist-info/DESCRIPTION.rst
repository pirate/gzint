It makes storing and comparing huge integers fast and lightweight, while gracefully falling back to normal integer operations when math is needed.  It works as a drop-in replacement for int.


