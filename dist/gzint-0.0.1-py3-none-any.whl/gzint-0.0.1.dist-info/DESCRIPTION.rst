integer operations when math is needed.  It works as a drop-in replacement for `int`.


